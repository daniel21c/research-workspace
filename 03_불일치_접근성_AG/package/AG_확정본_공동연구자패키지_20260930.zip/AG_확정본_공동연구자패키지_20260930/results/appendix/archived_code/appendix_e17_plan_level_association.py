# -*- coding: utf-8 -*-
"""구획 단위 연관성: 인구 분포를 공식안에 맞춘 SIZE20 앙상블(연도별 2사슬 × 500) 안에서 IFR과 7범주 경계 내 접근성(L·COV·MAI)의 관계 (2026-09-29).
저장된 7범주 재평가(e15_{y}_plans_7cat.csv)를 읽고, 모양(구 평균 PP)·전체 경계 길이를 통제한 편상관(Spearman)을 사슬 단위 블록 재표집으로 구간화.
새 경계·새 접근성 계산 없음(PP·경계 길이만 저장 라벨에서 계산).
"""
import json
import sys
from pathlib import Path

import numpy as np
import pandas as pd
from scipy.stats import rankdata

HERE = Path(__file__).resolve().parent; AG = HERE.parents[2]; ROOT = AG.parent; V3 = HERE.parent
sys.path.insert(0, str(AG / 'current' / 'code')); import study as S  # noqa: E402
OUT = HERE / 'out'; rng = np.random.default_rng(20260929)


def pres(v, C):
    X = np.column_stack([np.ones(len(v))] + [rankdata(c) for c in C]); r = rankdata(v); return r - X @ np.linalg.lstsq(X, r, rcond=None)[0]


def pc(x, y, C):
    return float(np.corrcoef(pres(x, C), pres(y, C))[0, 1]) if C else float(np.corrcoef(rankdata(x), rankdata(y))[0, 1])


def main():
    res = {}
    for y in (2025, 2020):
        paths = S.input_paths(ROOT, y); D = S.load(ROOT, y, paths)
        P = pd.read_csv(OUT / f'e15_{y}_plans_7cat.csv'); P = P[P.plan.str.startswith('E')].reset_index(drop=True)
        seeds = sorted(P.seed.unique()); pp_m, blen = [], []
        for s in seeds:
            L = np.load(V3 / 'out' / f'e13_{y}_SIZE20_{s}_labels.npz', allow_pickle=True)
            for i in range(500):
                lab = L[f'E{i:03d}'].astype(np.int64); zs = np.unique(lab); mem = [np.flatnonzero(lab == z) for z in zs]
                pp_m.append(np.mean([S.pp(D, m) for m in mem])); blen.append(sum(D['per'][m].sum() - D['S'][np.ix_(m, m)].sum() for m in mem) / 1e3)
        P['pp_mean'] = pp_m; P['boundary_km'] = blen; P.to_csv(OUT / f'e17_{y}_plans_with_shape.csv', index=False, encoding='utf-8-sig')
        out = {}
        for m, lab in (('L7', '누락 인구(낮을수록 좋음)'), ('COV15_7', 'COV'), ('MAI15_7', 'MAI')):
            for cn, C in (('raw', []), ('shape', ['pp_mean', 'boundary_km'])):
                est = pc(P.IFR.to_numpy(), P[m].to_numpy(), [P[c].to_numpy() for c in C])
                # 사슬 안 연속 50개 블록(20블록) 재표집
                blocks = [np.arange(j, j + 50) for j in range(0, len(P), 50)]; bs = []
                for _ in range(2000):
                    idx = np.concatenate([blocks[b] for b in rng.integers(len(blocks), size=len(blocks))]); d = P.iloc[idx]
                    bs.append(pc(d.IFR.to_numpy(), d[m].to_numpy(), [d[c].to_numpy() for c in C]))
                out[f'{m}|{cn}'] = {'label': lab, 'rho': est, 'ci95': [float(np.quantile(bs, .025)), float(np.quantile(bs, .975))]}
        res[y] = out; print(y, json.dumps(out, ensure_ascii=False))
    (OUT / 'e17_plan_level_association.json').write_text(json.dumps(res, ensure_ascii=False, indent=1), encoding='utf-8')


if __name__ == '__main__':
    main()
