# 보관 분석 코드 (현행 파이프라인 아님)

이 두 스크립트는 2026-09-28~29에 explore/v3 구조(common_v3.py, config_v3_run2A.json, current/code, e15 결과)에서 실행한 것으로, 현재 `code/`만으로는 돌지 않는다. 산출물(`../e13b_*_stagnant_search.csv`, `../plan_level_association.json`)은 부록 A3와 4.3절의 정체 구 열거 서술에 쓰였다. 재실행하려면 보관 폴더 `D:/Research/_archive/03_AG_확정전_정리_20260930/explore/v3/`가 필요하다. 본문 결과(표 2~4, 그림 2~4)는 이 코드에 의존하지 않는다.
