# -*- coding: utf-8 -*-
"""v3 2A: 경보가 난 구에서 같은 제약 아래 비자명 합법 대안이 있는지 제한된 탐색 (2026-09-28).
결과 지표(누락·접근성·IFR)를 보지 않는다. 예산·seed는 config에서.
(1) 동 수 ≤ exhaustive_max_dong 이면 연결 분할 완전 열거(시간 상한), (2) 아니면 LZ에서 인접 생활권 쌍마다 신장트리 budget개로 합법 분할 탐색.
실행: python v3/e13b_stagnant_gu_search.py <year> <seed>   (e13 chain_diag의 경보 구 대상)
"""
import json
import sys
import time
from pathlib import Path

import networkx as nx
import numpy as np
import pandas as pd

V3 = Path(__file__).resolve().parent; sys.path.insert(0, str(V3))
import common_v3 as C  # noqa: E402

CFG = json.load(open(V3 / 'config_v3_run2A.json', encoding='utf-8')); S = CFG['stagnant_search']
YEAR, SEED = int(sys.argv[1]), int(sys.argv[2]); TAG = f'{YEAR}_SIZE20_{SEED}'; OUT = V3 / 'out'


def enumerate_partitions(D, cons, k, nodes, t_cap, n_cap):
    G = D['G'].subgraph(nodes); nz = cons.nz[k]; ref = cons.ref_sorted[k]; popd = D['popd']
    lo_any, hi_any = (1 - cons.size_tol) * ref.min(), (1 + cons.size_tol) * ref.max()
    def ok_pop(p):
        return any((1 - cons.size_tol) * r <= p <= (1 + cons.size_tol) * r for r in ref)
    t0 = time.time(); found = []; state = {'timeout': False, 'n': 0}
    def subsets(R, r):
        """R 안에서 r을 포함하는 연결 부분집합(인구 상한 가지치기) 생성."""
        out = []
        def ext(Sset, frontier, excl, pop):
            if time.time() - t0 > t_cap:
                state['timeout'] = True; return
            if pop >= lo_any:
                out.append(frozenset(Sset))
            frontier = list(frontier)
            for i, v in enumerate(frontier):
                np_ = pop + popd[v]
                if np_ > hi_any:
                    continue
                newf = set(frontier[i + 1:]) | {u for u in G[v] if u in R and u not in Sset and u not in excl and u not in frontier[:i + 1]}
                ext(Sset | {v}, newf, excl | set(frontier[:i]), np_)
        ext({r}, {u for u in G[r] if u in R}, set(), popd[r])
        return out
    def rec(R, parts):
        if state['timeout'] or state['n'] >= n_cap:
            return
        if len(parts) == nz - 1:
            if nx.is_connected(G.subgraph(R)) and ok_pop(popd[list(R)].sum()):
                allp = parts + [frozenset(R)]
                if cons.pops_ok(k, [popd[list(p)].sum() for p in allp]) and cons.pp_ok(k, [C.pp(D, sorted(p)) for p in allp]):
                    found.append(tuple(sorted(tuple(sorted(p)) for p in allp))); state['n'] += 1
            return
        r = min(R)
        for Sset in subsets(R, r):
            if not ok_pop(popd[list(Sset)].sum()) or len(Sset) == len(R):
                continue
            rest = R - Sset
            if all(ok_pop(popd[list(c)].sum()) or len(c) > 1 for c in nx.connected_components(G.subgraph(rest))):
                rec(rest, parts + [Sset])
    rec(frozenset(nodes.tolist()), [])
    return len(set(found)), state['timeout'], time.time() - t0


def tree_search(D, cons, k, nodes, budget, rng):
    lab = D['LZ']; G = D['G']; popd = D['popd']; lz_key = C.comp_key(lab, nodes); legal = set()
    zs = np.unique(lab[nodes]); pairs = {tuple(sorted((lab[a], lab[b]))) for a, b in G.subgraph(nodes).edges() if lab[a] != lab[b]}
    for za, zb in sorted(pairs):
        merged = [n for n in nodes if lab[n] in (za, zb)]; Hm = G.subgraph(merged); tot = popd[merged].sum()
        oc = [c for c in zs if c not in (za, zb)]; opop = [popd[nodes][lab[nodes] == c].sum() for c in oc]; opp = [C.pp(D, nodes[lab[nodes] == c]) for c in oc]
        for _ in range(budget):
            T = nx.random_spanning_tree(Hm, seed=int(rng.integers(1 << 31)))
            for e in T.edges():
                T.remove_edge(*e); comp = nx.node_connected_component(T, e[0]); T.add_edge(*e); c1 = sorted(comp); c2 = [n for n in merged if n not in comp]
                if cons.pops_ok(k, opop + [popd[c1].sum(), tot - popd[c1].sum()]) and cons.pp_ok(k, opp + [C.pp(D, c1), C.pp(D, c2)]):
                    l2 = lab.copy()
                    for n in merged:
                        l2[n] = za if n in comp else zb
                    kk = C.comp_key(l2, nodes)
                    if kk != lz_key:
                        legal.add(kk)
    return len(legal)


def main():
    D = C.load(YEAR); cons = C.Constraints(D, 'SIZE', size_tol=CFG['ensemble']['size_tol'], pp_factor=CFG['ensemble']['pp_factor'])
    dg = pd.read_csv(OUT / f'e13_{TAG}_chain_diag.csv'); tgt = dg[dg.alarm_unique_lt10 | dg.alarm_differs_lt05]; rng = np.random.default_rng(S['seed']); rows = []
    for r in tgt.itertuples():
        nodes = np.flatnonzero(D['ku'] == r.ku)
        if len(nodes) <= S['exhaustive_max_dong']:
            n, to, sec = enumerate_partitions(D, cons, r.ku, nodes, S['exhaustive_time_cap_s'], S['exhaustive_count_cap'])
            rows.append({'ku': r.ku, 'ku_name': r.ku_name, 'n_dong': len(nodes), 'method': 'exhaustive', 'legal_partitions_found(incl LZ)': n, 'timeout': to, 'seconds': round(sec, 1),
                         'chain_saved_unique': r.saved_unique_states, 'verdict': ('구조적으로 LZ만 합법' if (n == 1 and not to) else ('비자명 대안 존재 → 사슬 탐색 부족' if n > r.saved_unique_states else ('탐색 미완(시간 상한)' if to else '사슬이 열거된 상태를 모두 방문')))})
        else:
            n = tree_search(D, cons, r.ku, nodes, S['tree_budget_per_pair'], rng)
            rows.append({'ku': r.ku, 'ku_name': r.ku_name, 'n_dong': len(nodes), 'method': f"tree search {S['tree_budget_per_pair']}/pair from LZ", 'legal_partitions_found(excl LZ, one move)': n,
                         'chain_saved_unique': r.saved_unique_states, 'verdict': '비자명 대안 존재(한 단계)' if n > 0 else '예산 안에서 대안 못 찾음(유일성 증명 아님)'})
    pd.DataFrame(rows).to_csv(OUT / f'e13b_{TAG}_stagnant_search.csv', index=False, encoding='utf-8-sig'); print(pd.DataFrame(rows).to_string(index=False))


if __name__ == '__main__':
    main()
