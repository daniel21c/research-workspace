#!/bin/bash
cd "/d/Research/00_박사논문_연구체계/01_생활권_필요성/code"
export TMP=/d/Research/_tmp TEMP=/d/Research/_tmp MPLCONFIGDIR=/d/Research/_tmp/mpl PYTHONIOENCODING=utf-8
L=../output/run0930
q() { name=$1; shift; ( for c in "$@"; do echo "[$(date +%H:%M:%S)] START $c" >> $L/$name.status; eval "python $c" > "$L/${name}_$(echo $c | tr ' %/' '___').log" 2>&1; echo "[$(date +%H:%M:%S)] END($?) $c" >> $L/$name.status; done; echo ALLDONE >> $L/$name.status ) & }
q Q1 "exp10_extra.py policy 2020 20" "exp10_extra.py stability 2020"
q Q2 "exp10_extra.py policy 2025 20" "exp10_extra.py stability 2025"
q Q3 "exp10_extra.py exposure 2020 40" "exp10_extra.py exposure 2025 40" "exp10_extra.py shuffle 2020 20" "exp10_extra.py shuffle 2025 20" "exp9_multi_facility.py 2020 40 중위60% new" "exp9_multi_facility.py 2025 40 중위60% new"
q Q4 "exp9_multi_facility.py 2025 40 중위60%" "exp9_multi_facility.py 2020 40 평균60%" "exp9_multi_facility.py 2025 40 평균60%"
q Q5 "milp_facility.py 2020 600 중위60%" "milp_facility.py 2025 600 중위60%" "milp_facility.py 2020 600 평균60%" "milp_check.py 2020 600" "milp_check.py 2025 600"
q Q6 "exp1_matrix.py 2020 도서관 31" "exp1_matrix.py 2025 도서관 31" "exp2_concealment.py" "exp4_equity_defs.py 2020" "exp4_equity_defs.py 2025" "exp5_7_admin_actual.py" "exp6_sensitivity.py 2020" "exp6_sensitivity.py 2025" "exp3_size_boundary.py 150 40 100" "exp8_case_gu.py 2020"
wait
