#!/usr/bin/env bash
# exp21 일괄(동시 8개, 각 7200초). 실행: code 폴더에서 bash ../results/_logs/run1002b/run_exp21.sh
L=../results/_logs/run1002b
while read y u m t; do echo "$y $u $m $t"; done < $L/exp21_jobs.txt | xargs -P 8 -L 1 bash -c 'PYTHONIOENCODING=utf-8 python exp21_floor_proof.py $0 $1 $2 $3 7200 > ../results/_logs/run1002b/exp21_$0_$1_$2_$3.log 2>&1; echo "finished $0 $1 $2 $3"'
echo ALLDONE
